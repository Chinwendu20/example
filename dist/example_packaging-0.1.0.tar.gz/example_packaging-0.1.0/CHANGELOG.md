# Changelog

## Unreleased

### Changed

## [0.1.0] - 2025-07-17

### Added

- Created rescale() function and released example_package_YOUR_USERNAME_HERE
